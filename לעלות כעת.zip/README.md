# NutriPlan v6

## מה יש בפנים
- App.jsx מתוקן עם מרכאות תקינות ל-React
- Supabase URL + publishable key מחוברים
- 11 מתכונים, מתכון אחד פתוח בחינם
- Basic: 5 מתכונים
- Pro/Elite: כל 11 המתכונים
- שדרוג מבחר הארוחות לסגנון שמתאים לשוק האמריקאי
- תקנון/פרטיות/החזרים חזקים יותר, עדיין דורש עורך דין לפני השקה מסחרית

## איפה לשים
החלף את הקובץ הקיים:
src/App.jsx

## Supabase
הקוד מנסה לשמור leads לטבלה בשם:
nutriplan_leads

אם אין טבלה כזאת, האתר עדיין יעבוד, אבל השמירה ל-Supabase לא תצליח.

SQL מומלץ:
create table nutriplan_leads (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  email text,
  plan text,
  marketing boolean,
  goal text,
  calories int,
  payload jsonb
);

## חשוב
כרגע unlock code הוא עדיין פתרון דמו. כדי שזה יהיה אמיתי ומוגן צריך בעתיד webhook/backend שמוודא תשלום.
