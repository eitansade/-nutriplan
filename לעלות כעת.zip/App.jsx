// NutriPlan App.jsx - MVP v6
// Ready for React/Vite single-file upload.
// IMPORTANT: Legal text is stronger than before, but it is NOT legal advice.
// Have a licensed attorney review before commercial launch.

import { useMemo, useState, useEffect } from "react";

const SUPABASE_URL = "https://abmixefrwcenyzluqlck.supabase.co";
const SUPABASE_ANON_KEY = "sb_publishable_z7qo9Jl_q5i3gja00ii4hw_ChhDVMxd";

const OWNER_CODE = "12/01/2000";
const STORAGE_KEY = "nutriplan_v6_mvp";
const SUPPORT_EMAIL = "hello.nutriplan@gmail.com";

const PAYPAL = {
  basic: "https://www.paypal.com/ncp/payment/XDWATET936BTS",
  pro: "https://www.paypal.com/ncp/payment/UWQCJ46HF8KHU",
  elite: "https://www.paypal.com/ncp/payment/L97A998HWV2ZW",
};

const PLANS = [
  {
    id: "free",
    name: "Free",
    price: "$0",
    badge: "Try it free",
    desc: "Taste the system before you upgrade.",
    features: [
      "1 full day of meals",
      "1 free premium-style recipe",
      "Preview locked paid content",
      "No credit card needed",
    ],
  },
  {
    id: "basic",
    name: "Basic",
    price: "$12",
    badge: "Starter",
    desc: "A simple 7-day plan with better meals and structure.",
    features: [
      "Full 7-day meal plan",
      "Smart calorie calculation",
      "Daily macro targets",
      "5 paid recipes",
    ],
  },
  {
    id: "pro",
    name: "Pro",
    price: "$27",
    badge: "Most popular",
    desc: "The realistic plan most people can actually follow.",
    features: [
      "Everything in Basic",
      "All 11 recipes",
      "Swap any meal",
      "Food calculator",
      "More American-market style meals",
    ],
    recommended: true,
  },
  {
    id: "elite",
    name: "Elite",
    price: "$49",
    badge: "Food + Training",
    desc: "Nutrition plus a weekly training program.",
    features: [
      "Everything in Pro",
      "Custom workouts",
      "Gym or home options",
      "Training schedule",
    ],
    premium: true,
  },
];

const isPaid = (t) => t !== "free";
const canSwap = (t) => ["pro", "elite"].includes(t);
const hasWorkouts = (t) => t === "elite";
const hasCalc = (t) => ["pro", "elite"].includes(t);
const hasBFP = (t) => ["basic", "pro", "elite"].includes(t);
const recipeLimit = (t) => (t === "free" ? 1 : t === "basic" ? 5 : 11);

const DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
const ACT = { sedentary: 1.2, light: 1.375, moderate: 1.55, active: 1.725 };

const FALLBACK_IMG =
  "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='900' height='500'%3E%3Crect fill='%2307090f' width='900' height='500'/%3E%3Ctext x='50%25' y='50%25' dominant-baseline='middle' text-anchor='middle' fill='%23a3e635' font-family='Arial' font-size='34'%3ENutriPlan%3C/text%3E%3C/svg%3E";

const IMG = {
  chicken: "https://images.unsplash.com/photo-1604909052743-94e838986d24?w=900&q=80",
  eggs: "https://images.unsplash.com/photo-1525351484163-7529414344d8?w=900&q=80",
  steak: "https://images.unsplash.com/photo-1558030006-450675393462?w=900&q=80",
  pasta: "https://images.unsplash.com/photo-1551183053-bf91a1d81141?w=900&q=80",
  salmon: "https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?w=900&q=80",
  yogurt: "https://images.unsplash.com/photo-1488477181946-6428a0291777?w=900&q=80",
  wrap: "https://images.unsplash.com/photo-1626700051175-6818013e1d4f?w=900&q=80",
  sandwich: "https://images.unsplash.com/photo-1553909489-cd47e0907980?w=900&q=80",
  burger: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=900&q=80",
  oats: "https://images.unsplash.com/photo-1517673408076-a2f27a2c0edf?w=900&q=80",
  bowl: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=900&q=80",
  tacos: "https://images.unsplash.com/photo-1565299585323-38d6b0865b47?w=900&q=80",
  pancakes: "https://images.unsplash.com/photo-1528207776546-365bb710ee93?w=900&q=80",
  sushi: "https://images.unsplash.com/photo-1579871494447-9811cf80d66c?w=900&q=80",
  smoothie: "https://images.unsplash.com/photo-1553530666-ba11a7da3888?w=900&q=80",
  pizza: "https://images.unsplash.com/photo-1513104890138-7c749659a591?w=900&q=80",
  chili: "https://images.unsplash.com/photo-1598514983318-2f64f8f4796c?w=900&q=80",
  noodles: "https://images.unsplash.com/photo-1569718212165-3a8278d5f624?w=900&q=80",
  apple: "https://images.unsplash.com/photo-1568702846914-96b305d2aaeb?w=900&q=80",
  nuts: "https://images.unsplash.com/photo-1508747703725-719777637510?w=900&q=80",
};

const S = {
  page: {
    minHeight: "100vh",
    background: "radial-gradient(circle at top left,#182235,#07090f 42%,#030407)",
    color: "#f8fafc",
    fontFamily: "Inter,system-ui,sans-serif",
  },
  wrap: { width: "min(1100px, calc(100% - 32px))", margin: "0 auto" },
  card: {
    background: "rgba(15,23,42,.82)",
    border: "1px solid rgba(148,163,184,.15)",
    borderRadius: 24,
    boxShadow: "0 20px 60px rgba(0,0,0,.25)",
  },
  inp: {
    width: "100%",
    boxSizing: "border-box",
    background: "rgba(2,6,23,.75)",
    color: "#fff",
    border: "1px solid rgba(148,163,184,.22)",
    borderRadius: 14,
    padding: "14px",
    fontSize: 16,
    outline: "none",
  },
  btn: {
    border: 0,
    borderRadius: 14,
    padding: "14px 18px",
    background: "linear-gradient(135deg,#f8fafc,#a3e635)",
    color: "#020617",
    fontWeight: 900,
    cursor: "pointer",
    fontSize: 15,
    textDecoration: "none",
  },
  sec: {
    border: "1px solid rgba(148,163,184,.2)",
    borderRadius: 14,
    padding: "14px 18px",
    background: "rgba(15,23,42,.72)",
    color: "#e2e8f0",
    fontWeight: 700,
    cursor: "pointer",
    fontSize: 15,
    textDecoration: "none",
  },
};

function loadState() {
  try {
    const r = window.localStorage.getItem(STORAGE_KEY);
    return r ? JSON.parse(r) : null;
  } catch {
    return null;
  }
}

function saveState(s) {
  try {
    const safe = { ...s };
    delete safe.marketingEmail;
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(safe));
  } catch {}
}

async function saveLeadToSupabase(payload) {
  // Create a table named nutriplan_leads in Supabase if you want this to save.
  // Columns suggestion: id uuid default gen_random_uuid(), created_at timestamptz default now(),
  // email text, plan text, marketing boolean, goal text, calories int, payload jsonb
  try {
    if (!SUPABASE_URL || !SUPABASE_ANON_KEY) return { ok: false };
    const res = await fetch(`${SUPABASE_URL}/rest/v1/nutriplan_leads`, {
      method: "POST",
      headers: {
        apikey: SUPABASE_ANON_KEY,
        Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
        "Content-Type": "application/json",
        Prefer: "return=minimal",
      },
      body: JSON.stringify(payload),
    });
    return { ok: res.ok };
  } catch {
    return { ok: false };
  }
}

const LEGAL = {
  terms: {
    title: "Terms of Service",
    body: `Last updated: ${new Date().getFullYear()}

IMPORTANT: This is a template and must be reviewed by a licensed attorney before full commercial launch.

1. Acceptance of Terms
By using NutriPlan, you agree to these Terms. If you do not agree, do not use the service. You must be at least 18 years old or have permission from a parent or legal guardian.

2. Educational Wellness Tool Only
NutriPlan provides general nutrition, fitness, and wellness information for educational purposes only. NutriPlan is not a medical provider, dietitian, clinic, or emergency service. Nothing in the app is medical advice, diagnosis, treatment, or a substitute for professional advice.

3. User Responsibility
You are solely responsible for your food choices, exercise choices, ingredient checks, allergies, intolerances, medical conditions, medications, and health decisions. Consult a qualified physician, registered dietitian, or healthcare professional before changing your diet, training, supplements, calories, or lifestyle.

4. Allergies and Food Safety
NutriPlan does not guarantee that meals are free of allergens or safe for every person. You must independently verify every ingredient, label, preparation method, and portion size.

5. No Guarantees
Results vary. NutriPlan does not guarantee weight loss, fat loss, muscle gain, improved health, or any specific outcome.

6. Payments and Access
Payments are processed by third-party providers such as PayPal. NutriPlan does not store credit card details. Access may depend on confirmation, unlock codes, or future backend verification.

7. Digital Product and Refunds
NutriPlan provides digital content. Once access is granted, purchases are generally final and non-refundable, except where required by law or where a verified technical issue prevents access and cannot be resolved.

8. Limitation of Liability
To the maximum extent permitted by law, NutriPlan and its owners are not liable for indirect, incidental, consequential, special, punitive, health-related, financial, or personal damages resulting from use or inability to use the service.

9. No Professional Relationship
Using NutriPlan does not create a doctor-patient, dietitian-client, trainer-client, attorney-client, or fiduciary relationship.

10. Contact
${SUPPORT_EMAIL}`,
  },
  privacy: {
    title: "Privacy Policy",
    body: `Last updated: ${new Date().getFullYear()}

IMPORTANT: This is a template and must be reviewed before launch.

1. Information You Enter
NutriPlan may collect information you voluntarily enter, such as age, weight, height, activity level, goal, food preferences, email address, and marketing consent.

2. Local Storage
Some non-sensitive preferences may be stored in your browser local storage to preserve your session. Email is not stored in local storage.

3. Supabase
If you enter an email or create a plan, limited data may be sent to Supabase for lead management and product functionality. Do not enter sensitive medical data.

4. Payments
Payments are processed by third-party providers such as PayPal. NutriPlan does not store your credit card details.

5. Marketing
If you opt in to marketing, we may contact you with product updates, offers, and wellness content. You may unsubscribe at any time.

6. No Sale of Personal Information
NutriPlan does not sell your personal information.

7. Data Security
No system is 100% secure. We use reasonable technical measures but cannot guarantee absolute security.

8. Contact
${SUPPORT_EMAIL}`,
  },
  refund: {
    title: "Refund Policy",
    body: `Last updated: ${new Date().getFullYear()}

Digital Product
NutriPlan provides digital wellness content. Once access is granted, sales are generally final and non-refundable.

Technical Problems
If a verified technical issue prevents access to your purchased plan, contact ${SUPPORT_EMAIL} within 48 hours with your PayPal receipt. We will try to resolve the issue.

No Results-Based Refunds
Refunds are not provided because of dissatisfaction with personal results, failure to lose weight, failure to gain muscle, or changes in motivation. Results vary and depend on many factors outside NutriPlan's control.

Legal Rights
Nothing in this policy limits rights you may have under applicable consumer protection law.`,
  },
};

function Pill({ children, color }) {
  return (
    <span
      style={{
        display: "inline-flex",
        border: "1px solid rgba(148,163,184,.18)",
        background: "rgba(15,23,42,.72)",
        color: color || "#cbd5e1",
        borderRadius: 999,
        padding: "6px 12px",
        fontSize: 12,
        fontWeight: 800,
      }}
    >
      {children}
    </span>
  );
}

function MacroBox({ icon, val, label }) {
  return (
    <div style={{ ...S.card, padding: 12, textAlign: "center" }}>
      <div style={{ fontSize: 18 }}>{icon}</div>
      <div style={{ fontSize: 20, fontWeight: 900 }}>{val}</div>
      <div style={{ fontSize: 11, color: "#64748b", fontWeight: 700 }}>{label}</div>
    </div>
  );
}

function Field({ label, error, children }) {
  return (
    <div style={{ display: "grid", gap: 6 }}>
      <label
        style={{
          color: "#94a3b8",
          fontSize: 12,
          fontWeight: 800,
          textTransform: "uppercase",
          letterSpacing: ".07em",
        }}
      >
        {label}
      </label>
      {children}
      {error && <div style={{ color: "#fca5a5", fontSize: 12 }}>{error}</div>}
    </div>
  );
}

function SafeImg({ src, alt, style }) {
  const [err, setErr] = useState(false);
  return <img src={err ? FALLBACK_IMG : src} alt={alt || ""} style={style} onError={() => setErr(true)} />;
}

function SliderField({ label, error, value, onChange, min, max, step = 1, unit }) {
  const numVal = Number(value) || min;
  const safeRange = max - min || 1;
  const pct = Math.min(100, Math.max(0, ((numVal - min) / safeRange) * 100));

  return (
    <div style={{ display: "grid", gap: 8 }}>
      <label style={{ color: "#94a3b8", fontSize: 12, fontWeight: 800, textTransform: "uppercase", letterSpacing: ".07em" }}>
        {label}
      </label>
      <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
        <input
          type="range"
          min={min}
          max={max}
          step={step}
          value={numVal}
          onChange={(e) => onChange(e.target.value)}
          style={{
            flex: 1,
            height: 6,
            borderRadius: 999,
            outline: "none",
            cursor: "pointer",
            appearance: "none",
            WebkitAppearance: "none",
            background: `linear-gradient(to right,#a3e635 ${pct}%,rgba(148,163,184,.18) ${pct}%)`,
          }}
        />
        <div style={{ minWidth: 72, textAlign: "right", fontSize: 22, fontWeight: 900 }}>
          {numVal}
          <span style={{ fontSize: 12, color: "#64748b", marginLeft: 3 }}>{unit}</span>
        </div>
      </div>
      {error && <div style={{ color: "#fca5a5", fontSize: 12 }}>{error}</div>}
      <style>{`input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;width:22px;height:22px;border-radius:50%;background:linear-gradient(135deg,#f8fafc,#a3e635);border:2px solid #020617;cursor:pointer;box-shadow:0 2px 8px rgba(0,0,0,.4)}input[type=range]::-moz-range-thumb{width:22px;height:22px;border-radius:50%;background:linear-gradient(135deg,#f8fafc,#a3e635);border:2px solid #020617;cursor:pointer}`}</style>
    </div>
  );
}

function LaunchBanner() {
  const [secsLeft, setSecsLeft] = useState(900);
  useEffect(() => {
    if (secsLeft <= 0) return;
    const t = setTimeout(() => setSecsLeft((s) => s - 1), 1000);
    return () => clearTimeout(t);
  }, [secsLeft]);

  if (secsLeft <= 0) return null;
  const mins = String(Math.floor(secsLeft / 60)).padStart(2, "0");
  const secs = String(secsLeft % 60).padStart(2, "0");

  return (
    <div
      style={{
        marginTop: 18,
        marginBottom: 18,
        borderRadius: 16,
        padding: "14px 18px",
        background: "linear-gradient(135deg,rgba(163,230,53,.12),rgba(56,189,248,.08))",
        border: "1px solid rgba(163,230,53,.25)",
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        gap: 12,
      }}
    >
      <div>
        <div style={{ fontSize: 13, fontWeight: 800, color: "#a3e635", marginBottom: 2 }}>Launch offer - 25% off</div>
        <div style={{ fontSize: 12, color: "#94a3b8" }}>Start today. Keep it realistic.</div>
      </div>
      <div style={{ fontVariantNumeric: "tabular-nums", fontSize: 22, fontWeight: 900, letterSpacing: 1 }}>
        {mins}:{secs}
      </div>
    </div>
  );
}

function LegalModal({ type, onClose }) {
  if (!type || !LEGAL[type]) return null;
  const { title, body } = LEGAL[type];

  return (
    <div
      role="dialog"
      aria-modal="true"
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 1000,
        background: "rgba(0,0,0,.85)",
        display: "flex",
        alignItems: "flex-end",
        justifyContent: "center",
      }}
      onClick={onClose}
    >
      <div
        style={{
          ...S.card,
          width: "100%",
          maxWidth: 720,
          maxHeight: "85vh",
          overflow: "hidden",
          display: "flex",
          flexDirection: "column",
          borderRadius: "24px 24px 0 0",
        }}
        onClick={(e) => e.stopPropagation()}
      >
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "20px 24px 16px", borderBottom: "1px solid rgba(148,163,184,.12)" }}>
          <h2 style={{ margin: 0, fontSize: 20, fontWeight: 900 }}>{title}</h2>
          <button aria-label="Close" onClick={onClose} style={{ background: "none", border: "none", color: "#94a3b8", fontSize: 26, cursor: "pointer", lineHeight: 1 }}>
            x
          </button>
        </div>
        <div style={{ overflowY: "auto", padding: "20px 24px 32px", color: "#94a3b8", fontSize: 14, lineHeight: 1.7, whiteSpace: "pre-wrap" }}>{body}</div>
      </div>
    </div>
  );
}

function LegalFooter({ onOpen }) {
  const lk = { color: "#64748b", fontSize: 12, cursor: "pointer", textDecoration: "underline" };
  return (
    <footer style={{ borderTop: "1px solid rgba(148,163,184,.08)", marginTop: 48, padding: "24px 0 40px", textAlign: "center" }}>
      <div style={{ display: "flex", gap: 20, justifyContent: "center", flexWrap: "wrap", marginBottom: 12 }}>
        <span style={lk} onClick={() => onOpen("terms")}>Terms of Service</span>
        <span style={lk} onClick={() => onOpen("privacy")}>Privacy Policy</span>
        <span style={lk} onClick={() => onOpen("refund")}>Refund Policy</span>
        <a href={"mailto:" + SUPPORT_EMAIL} style={{ ...lk, textDecoration: "none" }}>Contact Us</a>
      </div>
      <p style={{ color: "#334155", fontSize: 11, margin: 0, lineHeight: 1.6 }}>
        NutriPlan is not medical advice. Results vary. Always consult a qualified healthcare professional.
        <br />
        © {new Date().getFullYear()} NutriPlan. All rights reserved.
      </p>
    </footer>
  );
}

function food(name, amount, cal, protein, carbs, fat) {
  return { name, amount, cal, protein, carbs, fat };
}

function totals(items) {
  return items.reduce(
    (a, x) => ({
      cal: a.cal + x.cal,
      protein: a.protein + x.protein,
      carbs: a.carbs + x.carbs,
      fat: a.fat + x.fat,
    }),
    { cal: 0, protein: 0, carbs: 0, fat: 0 }
  );
}

function meal(title, img, items) {
  return { title, img, items, totals: totals(items) };
}

function scaleMeal(m, targetCal) {
  const f = Math.max(0.7, Math.min(1.35, targetCal / (m.totals.cal || 1)));
  const items = m.items.map((x) => ({
    ...x,
    cal: Math.round(x.cal * f),
    protein: Math.round(x.protein * f),
    carbs: Math.round(x.carbs * f),
    fat: Math.round(x.fat * f),
    amount: f > 1.12 ? `${x.amount} (larger)` : f < 0.88 ? `${x.amount} (smaller)` : x.amount,
  }));
  return { ...m, items, totals: totals(items) };
}

const FOODS = {
  breakfast: [
    meal("High-protein eggs and toast", IMG.eggs, [food("Eggs", "3 large", 220, 18, 1, 15), food("Sourdough", "2 slices", 220, 8, 40, 2), food("Avocado", "1/2", 160, 2, 8, 15)]),
    meal("Greek yogurt berry bowl", IMG.yogurt, [food("Greek yogurt", "1 cup", 210, 30, 12, 3), food("Banana", "1 medium", 105, 1, 27, 0), food("Walnuts", "small handful", 130, 3, 3, 13)]),
    meal("Protein oatmeal", IMG.oats, [food("Oats", "1 cup dry", 307, 10, 54, 6), food("Protein yogurt", "1/2 cup", 120, 17, 8, 2), food("Blueberries", "1/2 cup", 42, 0, 11, 0)]),
    meal("Breakfast burrito", IMG.wrap, [food("Flour tortilla", "1 large", 220, 7, 36, 6), food("Eggs", "2 large", 145, 12, 1, 10), food("Turkey slices", "3 oz", 90, 18, 1, 1), food("Cheese", "1 oz", 110, 7, 1, 9)]),
    meal("Protein pancakes", IMG.pancakes, [food("Protein pancake mix", "1 serving", 280, 22, 36, 6), food("Greek yogurt", "1/2 cup", 100, 15, 6, 1), food("Berries", "1/2 cup", 50, 1, 12, 0)]),
    meal("Smoothie bowl", IMG.smoothie, [food("Protein yogurt", "1 cup", 220, 30, 15, 3), food("Frozen berries", "1 cup", 80, 1, 20, 0), food("Granola", "1/3 cup", 160, 4, 28, 5)]),
  ],
  lunch: [
    meal("Chipotle-style chicken rice bowl", IMG.bowl, [food("Chicken breast", "7 oz", 330, 62, 0, 7), food("White rice", "1 cup cooked", 325, 6, 72, 1), food("Corn salsa", "1/2 cup", 80, 2, 18, 1), food("Olive oil", "1 tsp", 40, 0, 0, 5)]),
    meal("Salmon sweet potato plate", IMG.salmon, [food("Salmon", "7 oz", 420, 44, 0, 26), food("Sweet potato", "1 medium", 180, 4, 42, 0), food("Broccoli", "1 cup", 51, 4, 10, 1)]),
    meal("Grilled chicken wrap", IMG.wrap, [food("Grilled chicken", "6 oz", 300, 54, 0, 6), food("Flour tortilla", "1 large", 220, 7, 36, 6), food("Shredded cheese", "1 oz", 120, 8, 1, 9)]),
    meal("Steak salad bowl", IMG.steak, [food("Lean steak", "6 oz", 380, 46, 0, 20), food("Mixed greens", "2 cups", 35, 3, 6, 0), food("Olive oil", "1 tbsp", 120, 0, 0, 14)]),
    meal("Turkey burger bowl", IMG.burger, [food("Turkey patty", "6 oz", 330, 42, 0, 16), food("Potatoes", "250g", 210, 5, 48, 0), food("Pickles and salad", "1 bowl", 50, 2, 10, 0)]),
    meal("Tuna sushi bowl", IMG.sushi, [food("Tuna", "5 oz", 180, 40, 0, 1), food("Sushi rice", "1 cup", 260, 5, 58, 1), food("Avocado", "1/2", 160, 2, 8, 15), food("Soy sauce", "1 tbsp", 10, 1, 1, 0)]),
    meal("Chicken tacos", IMG.tacos, [food("Corn tortillas", "3", 180, 5, 36, 3), food("Chicken", "6 oz", 285, 52, 0, 6), food("Guacamole", "2 tbsp", 80, 1, 4, 7)]),
  ],
  dinner: [
    meal("Steak and potatoes", IMG.steak, [food("Steak", "8 oz", 610, 58, 0, 39), food("Potatoes", "2 medium", 270, 6, 60, 0), food("Butter", "2 tsp", 75, 0, 0, 8)]),
    meal("Salmon rice plate", IMG.salmon, [food("Salmon", "7 oz", 420, 44, 0, 26), food("White rice", "1 cup", 285, 5, 63, 1), food("Avocado", "1/2", 160, 2, 8, 15)]),
    meal("Lean beef pasta", IMG.pasta, [food("Lean ground beef", "6 oz", 390, 42, 0, 22), food("Pasta", "2 cups cooked", 390, 14, 78, 2), food("Parmesan", "1 tbsp", 85, 8, 1, 6)]),
    meal("Burger bowl", IMG.burger, [food("Burger patties", "6 oz", 420, 42, 0, 26), food("Potatoes", "side", 225, 5, 50, 0), food("Cheese", "1 oz", 120, 8, 1, 9)]),
    meal("Buffalo chicken bowl", IMG.chicken, [food("Chicken breast", "7 oz", 330, 62, 0, 7), food("Rice", "1 cup", 285, 5, 63, 1), food("Greek yogurt ranch", "2 tbsp", 60, 5, 3, 2)]),
    meal("Healthier pizza night", IMG.pizza, [food("Thin crust pizza", "2 slices", 520, 26, 60, 20), food("Chicken topping", "3 oz", 140, 26, 0, 3), food("Side salad", "1 bowl", 70, 3, 10, 3)]),
    meal("Turkey chili", IMG.chili, [food("Lean turkey", "7 oz", 360, 50, 0, 16), food("Beans", "1 cup", 230, 15, 40, 1), food("Tomato sauce", "1 cup", 90, 4, 18, 1)]),
    meal("High-protein ramen bowl", IMG.noodles, [food("Ramen noodles", "1 pack", 380, 9, 55, 14), food("Eggs", "2 large", 145, 12, 1, 10), food("Chicken", "5 oz", 235, 43, 0, 5), food("Vegetables", "1 cup", 60, 3, 12, 0)]),
  ],
  snack: [
    meal("Yogurt and berries", IMG.yogurt, [food("Protein yogurt", "3/4 cup", 180, 25, 12, 3), food("Mixed berries", "1/2 cup", 50, 1, 12, 0)]),
    meal("Apple and almond butter", IMG.apple, [food("Apple", "1 large", 115, 1, 30, 0), food("Almond butter", "1 tbsp", 120, 4, 4, 10)]),
    meal("Mixed nuts and chocolate", IMG.nuts, [food("Mixed nuts", "small handful", 210, 5, 6, 19), food("Dark chocolate", "1 small square", 80, 1, 9, 5)]),
    meal("Hard-boiled eggs", IMG.eggs, [food("Boiled eggs", "2 large", 145, 12, 1, 10), food("Fruit", "1 serving", 100, 1, 25, 0)]),
    meal("Turkey sandwich", IMG.sandwich, [food("Bread", "2 slices", 220, 8, 40, 2), food("Turkey", "4 oz", 120, 25, 1, 1), food("Light mayo", "1 tbsp", 45, 0, 1, 4)]),
  ],
};

const RECIPES = [
  {
    title: "Free Hook Recipe: Chipotle-Style Chicken Burrito Bowl",
    free: true,
    img: IMG.bowl,
    time: "20 min",
    calories: 620,
    protein: 55,
    tag: "Free recipe",
    ingredients: ["200g cooked chicken breast", "1 cup cooked white rice", "1/2 cup corn salsa", "1/2 avocado", "Lime, salt, chili flakes"],
    steps: ["Season chicken with salt, paprika, garlic and chili.", "Build a bowl with rice, chicken, corn salsa and avocado.", "Finish with lime. This is the style people can eat every week without feeling on a diet."],
  },
  {
    title: "High-Protein Breakfast Burrito",
    img: IMG.wrap,
    time: "12 min",
    calories: 540,
    protein: 42,
    tag: "American favorite",
    ingredients: ["1 large flour tortilla", "2 eggs", "100g egg whites", "60g turkey", "30g cheese", "Hot sauce"],
    steps: ["Scramble eggs and egg whites.", "Add turkey and cheese.", "Wrap tightly and toast in a pan."],
  },
  {
    title: "Buffalo Chicken Rice Bowl",
    img: IMG.chicken,
    time: "18 min",
    calories: 690,
    protein: 62,
    tag: "High protein",
    ingredients: ["200g chicken breast", "1 cup rice", "Buffalo sauce", "Greek yogurt ranch", "Cucumber and lettuce"],
    steps: ["Cook chicken and toss with buffalo sauce.", "Serve over rice.", "Add yogurt ranch and crunchy vegetables."],
  },
  {
    title: "Turkey Smash Burger Bowl",
    img: IMG.burger,
    time: "18 min",
    calories: 640,
    protein: 50,
    tag: "Comfort food",
    ingredients: ["180g lean ground turkey", "250g potatoes", "Pickles", "Lettuce", "Light burger sauce"],
    steps: ["Smash turkey into a hot pan.", "Air-fry or roast potatoes.", "Serve with pickles, lettuce and sauce."],
  },
  {
    title: "Protein Pancake Stack",
    img: IMG.pancakes,
    time: "15 min",
    calories: 480,
    protein: 38,
    tag: "Sweet craving",
    ingredients: ["Protein pancake mix", "Greek yogurt", "Berries", "Sugar-free maple or honey"],
    steps: ["Prepare pancakes.", "Top with yogurt and berries.", "Use a small amount of syrup or honey."],
  },
  {
    title: "Tuna Sushi Bowl",
    img: IMG.sushi,
    time: "15 min",
    calories: 610,
    protein: 48,
    tag: "Fresh",
    ingredients: ["150g tuna", "1 cup sushi rice", "Cucumber", "Avocado", "Soy sauce"],
    steps: ["Place rice in a bowl.", "Add tuna, cucumber and avocado.", "Finish with soy and sesame."],
  },
  {
    title: "Lean Beef Pasta",
    img: IMG.pasta,
    time: "22 min",
    calories: 760,
    protein: 55,
    tag: "Muscle meal",
    ingredients: ["180g lean beef", "2 cups cooked pasta", "Tomato sauce", "Parmesan"],
    steps: ["Brown beef.", "Add tomato sauce.", "Mix with pasta and parmesan."],
  },
  {
    title: "Chicken Tacos With Guacamole",
    img: IMG.tacos,
    time: "18 min",
    calories: 590,
    protein: 52,
    tag: "Easy dinner",
    ingredients: ["180g chicken", "3 corn tortillas", "Guacamole", "Salsa", "Lime"],
    steps: ["Season and cook chicken.", "Warm tortillas.", "Build tacos with salsa and guacamole."],
  },
  {
    title: "Greek Yogurt Smoothie Bowl",
    img: IMG.smoothie,
    time: "7 min",
    calories: 430,
    protein: 34,
    tag: "Quick",
    ingredients: ["Greek yogurt", "Frozen berries", "Banana", "Granola"],
    steps: ["Blend yogurt, berries and banana.", "Pour into a bowl.", "Top with granola."],
  },
  {
    title: "Healthier Pizza Night",
    img: IMG.pizza,
    time: "10 min",
    calories: 700,
    protein: 45,
    tag: "Real life",
    ingredients: ["2 thin-crust slices", "Chicken topping", "Side salad", "Light dressing"],
    steps: ["Eat the pizza you want, but add protein.", "Add salad for volume.", "Stop when satisfied, not stuffed."],
  },
  {
    title: "Turkey Chili Meal Prep",
    img: IMG.chili,
    time: "35 min",
    calories: 620,
    protein: 58,
    tag: "Meal prep",
    ingredients: ["Lean turkey", "Beans", "Tomato sauce", "Chili spices", "Rice optional"],
    steps: ["Cook turkey.", "Add beans, tomato sauce and spices.", "Simmer and divide into boxes."],
  },
];

function calcBMR(kg, cm, age, gender) {
  return gender === "female" ? Math.round(10 * kg + 6.25 * cm - 5 * age - 161) : Math.round(10 * kg + 6.25 * cm - 5 * age + 5);
}

function calcBFP(waist, neck, height, gender, hip) {
  try {
    if (gender === "male") {
      const d = waist - neck;
      if (d <= 0 || height <= 0) return null;
      const r = 495 / (1.0324 - 0.19077 * Math.log10(d) + 0.15456 * Math.log10(height)) - 450;
      return r < 2 || r > 70 ? null : r.toFixed(1);
    }
    const s = waist + (hip || 0) - neck;
    if (s <= 0 || height <= 0 || !hip) return null;
    const r = 495 / (1.29579 - 0.35004 * Math.log10(s) + 0.221 * Math.log10(height)) - 450;
    return r < 2 || r > 70 ? null : r.toFixed(1);
  } catch {
    return null;
  }
}

function pickMeal(options, seed) {
  return options[Math.abs(seed) % options.length];
}

function buildMealPlan(tier, form) {
  const age = Number(form.age) || 30;
  const kg = Number(form.weight) || 75;
  const cm = Number(form.height) || 175;
  let cal = Number(form.calories) || 2000;

  if (isPaid(tier)) {
    const maint = Math.round(calcBMR(kg, cm, age, form.gender) * (ACT[form.activity] || 1.375));
    const def = form.lossSpeed === "gentle" ? 200 : form.lossSpeed === "steady" ? 400 : 550;
    cal = form.goal === "lose" ? maint - def : form.goal === "gain" ? maint + 250 : maint;
  }

  const minCal = form.gender === "female" ? 1200 : 1500;
  cal = Math.max(minCal, Math.min(5000, cal));

  const slots = Number(form.mealsPerDay) === 3 ? ["breakfast", "lunch", "dinner"] : ["breakfast", "lunch", "dinner", "snack"];
  const dist = slots.length === 3 ? { breakfast: 0.28, lunch: 0.38, dinner: 0.34 } : { breakfast: 0.24, lunch: 0.34, dinner: 0.32, snack: 0.1 };
  const protein = Math.max(Math.round(kg * 1.6), Math.round((cal * 0.28) / 4));
  const fat = Math.round((cal * 0.28) / 9);
  const carbs = Math.max(80, Math.round((cal - protein * 4 - fat * 9) / 4));

  return {
    cal,
    slots,
    protein,
    carbs,
    fat,
    days: DAYS.map((day, di) => {
      const locked = tier === "free" && di >= 1;
      const meals = {};
      slots.forEach((slot, si) => {
        const seed = di * 17 + si * 9 + (form.biggestStruggle || "").length + (form.foodPreference || "").length;
        meals[slot] = scaleMeal(pickMeal(FOODS[slot], seed), cal * dist[slot]);
      });
      return { day, locked, isTraining: false, meals };
    }),
  };
}

const WORKOUT_BANK = {
  "Full Body A": { gym: ["Squat", "Bench press", "Lat pulldown", "Romanian deadlift"], home: ["Push-ups", "Squats", "Rows", "Plank"] },
  "Full Body B": { gym: ["Deadlift", "Incline press", "Seated row", "Leg press"], home: ["Pull-ups", "Split squats", "Dips", "Leg raises"] },
  "Upper Body": { gym: ["Bench press", "Lat pulldown", "Shoulder press", "Cable row"], home: ["Push-ups", "Pull-ups", "Pike push-ups", "Rows"] },
  "Lower Body": { gym: ["Squat", "Romanian deadlift", "Leg press", "Leg curl"], home: ["Squats", "Lunges", "Glute bridge", "Calf raises"] },
  Push: { gym: ["Bench press", "Incline press", "Shoulder press", "Tricep dips"], home: ["Push-ups", "Decline push-ups", "Pike push-ups", "Chair dips"] },
  Pull: { gym: ["Pull-ups", "Barbell row", "Lat pulldown", "Bicep curls"], home: ["Pull-ups", "Inverted rows", "Towel rows", "Backpack curls"] },
  Legs: { gym: ["Squat", "Leg press", "Romanian deadlift", "Calf raises"], home: ["Squats", "Lunges", "Jump squats", "Calf raises"] },
};

const SPLITS = {
  fullBody: ["Full Body A", "Full Body B", "Full Body A"],
  upperLower: ["Upper Body", "Lower Body", "Upper Body", "Lower Body"],
  ppl: ["Push", "Pull", "Legs", "Push", "Pull"],
};

function buildWorkouts(form) {
  const count = Math.min(Number(form.workoutsPerWeek) || 3, 5);
  const sets = form.level === "beginner" ? 3 : form.level === "intermediate" ? 4 : 5;
  const reps = form.level === "beginner" ? "8-10" : form.level === "intermediate" ? "8-12" : "6-12";
  const rest = form.level === "advanced" ? "90-150s" : "60-90s";
  const place = form.trainingPlace === "home" ? "home" : "gym";
  const split = SPLITS[form.workoutStyle] || SPLITS.fullBody;

  return Array.from({ length: count }, (_, i) => {
    const title = split[i % split.length];
    const exList = (WORKOUT_BANK[title] || WORKOUT_BANK["Full Body A"])[place];
    return {
      day: DAYS[i],
      title,
      notes: `${form.level} - ${place} - Keep 1-2 reps in reserve`,
      exercises: exList.map((name) => ({
        name,
        sets,
        rest,
        reps: name.toLowerCase().includes("plank") ? "30-60s" : reps,
      })),
    };
  });
}

function MealCard({ slot, mealObj, locked, allowSwap, onSwap, onUpgrade }) {
  return (
    <div style={{ ...S.card, overflow: "hidden", position: "relative" }}>
      {locked && (
        <div
          style={{
            position: "absolute",
            inset: 0,
            zIndex: 5,
            background: "rgba(2,6,23,.88)",
            backdropFilter: "blur(10px)",
            display: "grid",
            placeItems: "center",
            padding: 24,
            textAlign: "center",
          }}
        >
          <div>
            <div style={{ fontSize: 36, marginBottom: 10 }}>🔒</div>
            <Pill>Locked day</Pill>
            <h3 style={{ margin: "14px 0 8px", fontSize: 20 }}>Unlock the full 7-day plan</h3>
            <p style={{ color: "#cbd5e1", marginBottom: 18, lineHeight: 1.65, fontSize: 14 }}>Upgrade to get every day, meal swaps, recipes and calculator tools.</p>
            <button onClick={onUpgrade} style={{ ...S.btn, width: "100%" }}>Unlock Full Plan</button>
          </div>
        </div>
      )}

      <div style={{ height: 160, position: "relative" }}>
        <SafeImg src={mealObj.img} alt={mealObj.title} style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} />
        <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to top,rgba(2,6,23,.95),rgba(2,6,23,.1))" }} />
        <div style={{ position: "absolute", left: 14, right: 14, bottom: 14, display: "flex", justifyContent: "space-between", alignItems: "flex-end", gap: 10 }}>
          <div>
            <div style={{ color: "#94a3b8", fontSize: 11, fontWeight: 800, textTransform: "capitalize" }}>{slot}</div>
            <h3 style={{ margin: "3px 0 0", fontSize: 20, lineHeight: 1.2 }}>{mealObj.title}</h3>
          </div>
          {allowSwap && <button onClick={onSwap} style={{ ...S.sec, padding: "8px 14px", borderRadius: 999, fontSize: 13 }}>Swap</button>}
        </div>
      </div>

      <div style={{ padding: 16 }}>
        {mealObj.items.map((item) => (
          <div key={item.name + item.amount} style={{ display: "flex", justifyContent: "space-between", gap: 12, padding: "9px 0", borderTop: "1px solid rgba(148,163,184,.09)" }}>
            <div>
              <strong style={{ fontSize: 14 }}>{item.name}</strong>
              <div style={{ color: "#94a3b8", fontSize: 12 }}>{item.amount}</div>
              <div style={{ color: "#64748b", fontSize: 11 }}>{item.protein}g protein - {item.carbs}g carbs - {item.fat}g fat</div>
            </div>
            <strong style={{ color: "#a3e635", whiteSpace: "nowrap" }}>{item.cal} cal</strong>
          </div>
        ))}

        <div style={{ marginTop: 12, display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 8 }}>
          <MacroBox icon="🔥" val={mealObj.totals.cal} label="cal" />
          <MacroBox icon="🥩" val={mealObj.totals.protein + "g"} label="protein" />
          <MacroBox icon="🍚" val={mealObj.totals.carbs + "g"} label="carbs" />
          <MacroBox icon="🥑" val={mealObj.totals.fat + "g"} label="fat" />
        </div>
      </div>
    </div>
  );
}

function RecipeCard({ r, locked, onUpgrade }) {
  return (
    <div style={{ ...S.card, overflow: "hidden", position: "relative" }}>
      {locked && (
        <div style={{ position: "absolute", inset: 0, zIndex: 6, display: "grid", placeItems: "center", background: "rgba(2,6,23,.86)", backdropFilter: "blur(8px)", padding: 24, textAlign: "center" }}>
          <div>
            <div style={{ fontSize: 32 }}>🔒</div>
            <h3 style={{ margin: "10px 0 8px" }}>Recipe locked</h3>
            <p style={{ color: "#94a3b8", fontSize: 14, lineHeight: 1.55 }}>Upgrade to Pro to unlock all 11 recipes.</p>
            <button onClick={onUpgrade} style={S.btn}>Unlock recipes</button>
          </div>
        </div>
      )}
      <div style={{ height: 170, position: "relative" }}>
        <SafeImg src={r.img} alt={r.title} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
        <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to top,rgba(2,6,23,.95),rgba(2,6,23,.1))" }} />
        <div style={{ position: "absolute", bottom: 14, left: 14, right: 14 }}>
          <Pill color={r.free ? "#a3e635" : "#38bdf8"}>{r.tag}</Pill>
          <h3 style={{ margin: "8px 0 0", fontSize: 19 }}>{r.title}</h3>
        </div>
      </div>
      <div style={{ padding: 16 }}>
        <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginBottom: 12 }}>
          <Pill>{r.time}</Pill>
          <Pill>{r.calories} cal</Pill>
          <Pill>{r.protein}g protein</Pill>
        </div>
        <strong style={{ fontSize: 13, color: "#cbd5e1" }}>Ingredients</strong>
        <ul style={{ color: "#94a3b8", fontSize: 13, lineHeight: 1.55, paddingLeft: 18 }}>
          {r.ingredients.map((x) => <li key={x}>{x}</li>)}
        </ul>
        <strong style={{ fontSize: 13, color: "#cbd5e1" }}>Steps</strong>
        <ol style={{ color: "#94a3b8", fontSize: 13, lineHeight: 1.55, paddingLeft: 18 }}>
          {r.steps.map((x) => <li key={x}>{x}</li>)}
        </ol>
      </div>
    </div>
  );
}

function CalorieCalculator() {
  const [c, setC] = useState({ name: "", grams: "", cal100: "", p100: "", c100: "", f100: "" });
  const g = Number(c.grams) / 100 || 0;
  const r = {
    cal: Math.round((Number(c.cal100) || 0) * g),
    p: Math.round((Number(c.p100) || 0) * g),
    carb: Math.round((Number(c.c100) || 0) * g),
    fat: Math.round((Number(c.f100) || 0) * g),
  };

  return (
    <div style={{ ...S.card, padding: 20, marginTop: 20 }}>
      <Pill color="#38bdf8">Pro tool</Pill>
      <h3 style={{ margin: "10px 0 4px" }}>Food Calculator</h3>
      <p style={{ color: "#94a3b8", margin: "0 0 14px", fontSize: 14 }}>Use the nutrition label from any package.</p>
      <div style={{ display: "grid", gap: 10 }}>
        {[
          ["Food name", "text", "name", "e.g. Cottage cheese"],
          ["Grams eaten", "number", "grams", "150"],
          ["Calories per 100g", "number", "cal100", "100"],
          ["Protein per 100g", "number", "p100", "12"],
          ["Carbs per 100g", "number", "c100", "4"],
          ["Fat per 100g", "number", "f100", "5"],
        ].map(([lbl, type, key, ph]) => (
          <input key={key} aria-label={lbl} style={S.inp} type={type} placeholder={ph} value={c[key]} onChange={(e) => setC((prev) => ({ ...prev, [key]: e.target.value }))} />
        ))}
      </div>
      <div style={{ marginTop: 14, display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 8 }}>
        <MacroBox icon="🔥" val={r.cal} label="cal" />
        <MacroBox icon="🥩" val={r.p + "g"} label="protein" />
        <MacroBox icon="🍚" val={r.carb + "g"} label="carbs" />
        <MacroBox icon="🥑" val={r.fat + "g"} label="fat" />
      </div>
    </div>
  );
}

function WorkoutCard({ w }) {
  return (
    <div style={{ ...S.card, padding: 18 }}>
      <div style={{ color: "#a3e635", fontSize: 12, fontWeight: 800 }}>{w.day}</div>
      <h3 style={{ margin: "4px 0 6px" }}>{w.title}</h3>
      <p style={{ color: "#94a3b8", fontSize: 13, margin: "0 0 10px" }}>{w.notes}</p>
      {w.exercises.map((ex) => (
        <div key={ex.name} style={{ display: "flex", justifyContent: "space-between", borderTop: "1px solid rgba(148,163,184,.09)", padding: "9px 0" }}>
          <div>
            <strong style={{ fontSize: 14 }}>{ex.name}</strong>
            <div style={{ color: "#64748b", fontSize: 12 }}>Rest: {ex.rest}</div>
          </div>
          <strong>{ex.sets} x {ex.reps}</strong>
        </div>
      ))}
    </div>
  );
}

function NutriCoach({ tier, struggle, onUpgrade }) {
  const map = {
    late_night: "late-night cravings",
    takeout: "too much takeout",
    dont_know: "not knowing what to eat",
    training_no_results: "training without seeing results",
    busy: "a busy schedule",
    boring_diets: "boring diets that never stick",
  };
  const struggleText = map[struggle] || "your current challenge";

  return (
    <div style={{ ...S.card, padding: 20, background: "linear-gradient(135deg,rgba(163,230,53,.08),rgba(15,23,42,.8))", marginTop: 20 }}>
      <Pill color="#a3e635">Your coach says</Pill>
      <h3 style={{ margin: "10px 0 8px" }}>Built for real people</h3>
      <p style={{ color: "#dbeafe", lineHeight: 1.7, margin: "0 0 8px" }}>
        Your biggest challenge is <em style={{ color: "#e2e8f0" }}>{struggleText}</em>. That usually means you need structure and flexibility, not a stricter boring diet.
      </p>
      {tier !== "elite" && <button onClick={onUpgrade} style={S.btn}>{tier === "free" ? "Get the full plan" : "Unlock the next level"}</button>}
    </div>
  );
}

export default function App() {
  const restored = loadState();

  const [screen, setScreen] = useState("home");
  const [selectedTier, setSelTier] = useState(restored?.accessTier || "pro");
  const [accessTier, setAccess] = useState(restored?.accessTier || "free");
  const [unlockCode, setUCode] = useState("");
  const [unlockError, setUError] = useState("");
  const [errors, setErrors] = useState({});
  const [openDay, setOpenDay] = useState(0);
  const [plan, setPlan] = useState(null);
  const [generating, setGenerating] = useState(false);
  const [planReady, setPlanReady] = useState(false);
  const [agreedToTerms, setAgreed] = useState(false);
  const [termsError, setTermsError] = useState(false);
  const [legalModal, setLegalModal] = useState(null);
  const [activeTab, setActiveTab] = useState("meals");
  const [leadSaved, setLeadSaved] = useState(false);

  const [form, setForm] = useState(
    restored?.form || {
      calories: "2000",
      gender: "male",
      age: "30",
      weight: "75",
      height: "175",
      waist: "",
      neck: "",
      hip: "",
      activity: "light",
      goal: "lose",
      mealsPerDay: "4",
      biggestStruggle: "late_night",
      foodPreference: "balanced",
      lossSpeed: "steady",
      workoutsPerWeek: "3",
      workoutStyle: "fullBody",
      trainingPlace: "gym",
      level: "beginner",
      marketingEmail: "",
      marketingConsent: false,
    }
  );

  const selPlan = useMemo(() => PLANS.find((p) => p.id === selectedTier) || PLANS[2], [selectedTier]);

  function setVal(k, v) {
    setForm((f) => ({ ...f, [k]: v }));
    setErrors((e) => ({ ...e, [k]: "" }));
  }

  function choosePlan(id) {
    const tier = id === "eliteMonthly" ? "elite" : id;
    setSelTier(tier);
    setUCode("");
    setUError("");
    if (tier === "free") {
      setAccess("free");
      setScreen("onboarding");
    } else {
      setScreen("unlock");
    }
  }

  function unlockWithCode() {
    // Demo unlock. Real production should verify payment through a secure backend/webhook.
    if (unlockCode.trim() === OWNER_CODE) {
      setAccess(selectedTier);
      setUError("");
      setScreen("onboarding");
    } else {
      setUError("Invalid unlock code. If you paid, contact " + SUPPORT_EMAIL + " with your PayPal receipt.");
    }
  }

  function upgradeFrom() {
    if (accessTier === "free" || accessTier === "basic") choosePlan("pro");
    else if (accessTier === "pro") choosePlan("elite");
  }

  function validate() {
    const errs = {};
    if (!isPaid(accessTier)) {
      const cal = Number(form.calories);
      if (!cal || cal < 1200 || cal > 5000) errs.calories = "Enter a number between 1200 and 5000.";
    }
    if (isPaid(accessTier)) {
      const age = Number(form.age);
      const kg = Number(form.weight);
      const cm = Number(form.height);
      if (!age || age < 16 || age > 99) errs.age = "Age must be 16-99.";
      if (!kg || kg < 30 || kg > 250) errs.weight = "Weight must be 30-250 kg.";
      if (!cm || cm < 120 || cm > 220) errs.height = "Height must be 120-220 cm.";
    }
    if (form.marketingEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.marketingEmail)) errs.marketingEmail = "Enter a valid email.";
    setErrors(errs);
    return Object.keys(errs).length === 0;
  }

  function swapMeal(dayIdx, slot) {
    if (!plan || !canSwap(plan.tier)) return;
    const updated = plan.days.map((d, i) => {
      if (i !== dayIdx) return d;
      const options = FOODS[slot];
      const cur = d.meals[slot];
      const others = options.filter((m) => m.title !== cur.title);
      const next = others.length ? others[Math.floor(Math.random() * others.length)] : options[0];
      return { ...d, meals: { ...d.meals, [slot]: scaleMeal(next, plan.cal / plan.slots.length) } };
    });
    setPlan({ ...plan, days: updated });
  }

  async function generate() {
    if (!agreedToTerms) {
      setTermsError(true);
      return;
    }
    setTermsError(false);
    if (!validate()) return;

    setGenerating(true);

    const mealPlan = buildMealPlan(accessTier, form);
    const workouts = hasWorkouts(accessTier) ? buildWorkouts(form) : [];
    workouts.forEach((w) => {
      const idx = DAYS.indexOf(w.day);
      if (idx >= 0 && mealPlan.days[idx]) mealPlan.days[idx].isTraining = true;
    });

    const bfp =
      hasBFP(accessTier) && form.waist && form.neck
        ? calcBFP(Number(form.waist), Number(form.neck), Number(form.height), form.gender, Number(form.hip) || 0)
        : null;

    const newPlan = { ...mealPlan, workouts, bfp, tier: accessTier };
    setPlan(newPlan);
    saveState({ form, accessTier });

    if (form.marketingEmail) {
      const payload = {
        email: form.marketingEmail,
        plan: accessTier,
        marketing: Boolean(form.marketingConsent),
        goal: form.goal,
        calories: newPlan.cal,
        payload: {
          age: form.age,
          gender: form.gender,
          weight: form.weight,
          height: form.height,
          activity: form.activity,
          preference: form.foodPreference,
          struggle: form.biggestStruggle,
        },
      };
      const saved = await saveLeadToSupabase(payload);
      setLeadSaved(saved.ok);
    }

    setOpenDay(0);
    setActiveTab("meals");
    setGenerating(false);
    setPlanReady(true);
    setScreen("results");
  }

  function reset() {
    setPlan(null);
    setAccess("free");
    setScreen("home");
    setPlanReady(false);
    setAgreed(false);
    try {
      window.localStorage.removeItem(STORAGE_KEY);
    } catch {}
  }

  if (screen === "home") {
    return (
      <div style={S.page}>
        <div style={{ ...S.wrap, padding: "28px 0 70px" }}>
          <header style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 40 }}>
            <div style={{ fontSize: 22, fontWeight: 900, letterSpacing: -0.5 }}>NutriPlan</div>
            <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
              <Pill>Real food. Realistic progress.</Pill>
              <button onClick={reset} style={{ ...S.sec, padding: "8px 14px", borderRadius: 999, fontSize: 13 }}>Reset</button>
            </div>
          </header>

          <LaunchBanner />

          <section style={{ textAlign: "center", marginBottom: 50, paddingTop: 12 }}>
            <h1 style={{ fontSize: "clamp(34px,8vw,80px)", lineHeight: 0.93, letterSpacing: -3, margin: "0 auto 20px", maxWidth: 860 }}>
              Lose weight without eating like a fitness robot.
            </h1>
            <p style={{ color: "#94a3b8", fontSize: 18, lineHeight: 1.65, maxWidth: 640, margin: "0 auto 30px" }}>
              Real food. Real life. American-style meals people actually want to eat: bowls, wraps, burritos, burgers, pasta, sushi bowls and high-protein comfort food.
            </p>
            <button onClick={() => choosePlan("pro")} style={{ ...S.btn, padding: "16px 36px", fontSize: 17 }}>Get My Plan - $27</button>
            <div style={{ marginTop: 10, color: "#64748b", fontSize: 12 }}>Or try the free preview. No credit card needed.</div>
          </section>

          <div style={{ display: "flex", flexWrap: "wrap", justifyContent: "center", gap: "10px 24px", marginBottom: 40 }}>
            {["No extreme diets", "Real food meals", "Built for busy people", "Results vary", "Not medical advice"].map((t) => (
              <span key={t} style={{ color: "#64748b", fontSize: 13, display: "flex", alignItems: "center", gap: 6 }}>
                <span style={{ color: "#a3e635" }}>✓</span>
                {t}
              </span>
            ))}
          </div>

          <div style={{ ...S.card, padding: "22px 26px", marginBottom: 36, background: "rgba(15,23,42,.6)" }}>
            <div style={{ color: "#a3e635", fontSize: 12, fontWeight: 800, textTransform: "uppercase", letterSpacing: ".08em", marginBottom: 10 }}>What changed in v6</div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(210px,1fr))", gap: "10px 24px" }}>
              {[
                "Supabase connected for lead capture",
                "11 recipes with 1 strong free recipe",
                "Expanded American-market meal choices",
                "Stronger legal acceptance flow",
                "Cleaner JSX quotes and safer code",
              ].map((item) => (
                <div key={item} style={{ color: "#cbd5e1", fontSize: 14, display: "flex", gap: 8 }}>
                  <span style={{ color: "#a3e635" }}>→</span>
                  {item}
                </div>
              ))}
            </div>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(220px,1fr))", gap: 14 }}>
            {PLANS.map((p) => (
              <div
                key={p.id}
                style={{
                  ...S.card,
                  padding: 20,
                  position: "relative",
                  border: p.recommended ? "1px solid rgba(163,230,53,.5)" : p.premium ? "1px solid rgba(192,132,252,.5)" : S.card.border,
                  background: p.recommended
                    ? "linear-gradient(180deg,rgba(163,230,53,.1),rgba(15,23,42,.8))"
                    : p.premium
                    ? "linear-gradient(180deg,rgba(192,132,252,.1),rgba(15,23,42,.8))"
                    : S.card.background,
                }}
              >
                {p.recommended && (
                  <div style={{ position: "absolute", top: -10, left: "50%", transform: "translateX(-50%)", background: "#a3e635", color: "#020617", fontSize: 11, fontWeight: 900, padding: "4px 14px", borderRadius: 999, whiteSpace: "nowrap" }}>
                    MOST POPULAR
                  </div>
                )}
                <Pill>{p.badge}</Pill>
                <h2 style={{ margin: "10px 0 2px", fontSize: 24 }}>{p.name}</h2>
                <div style={{ fontSize: 34, fontWeight: 900, marginBottom: 4 }}>{p.price}</div>
                <p style={{ color: "#94a3b8", minHeight: 54, fontSize: 14, margin: "0 0 14px", lineHeight: 1.55 }}>{p.desc}</p>
                {p.features.map((f) => (
                  <div key={f} style={{ color: "#cbd5e1", fontSize: 13, marginBottom: 8, display: "flex", gap: 8, alignItems: "flex-start" }}>
                    <span style={{ color: "#a3e635", flexShrink: 0 }}>✓</span>
                    {f}
                  </div>
                ))}
                <button onClick={() => choosePlan(p.id)} style={{ ...(p.id === "free" ? S.sec : S.btn), width: "100%", marginTop: 16 }}>
                  {p.id === "free" ? "Try free preview" : "Get " + p.name + " - " + p.price}
                </button>
              </div>
            ))}
          </div>

          <LegalFooter onOpen={setLegalModal} />
        </div>
        <LegalModal type={legalModal} onClose={() => setLegalModal(null)} />
      </div>
    );
  }

  if (screen === "unlock") {
    return (
      <div style={S.page}>
        <div style={{ ...S.wrap, maxWidth: 540, padding: "28px 0 70px" }}>
          <button onClick={() => setScreen("home")} style={S.sec}>Back</button>
          <LaunchBanner />

          <div style={{ ...S.card, padding: 28, marginTop: 18 }}>
            <Pill>{selPlan.badge}</Pill>
            <h1 style={{ fontSize: 32, letterSpacing: -1, margin: "14px 0 6px" }}>{selPlan.name} Plan - {selPlan.price}</h1>
            <p style={{ color: "#94a3b8", lineHeight: 1.65, margin: "0 0 20px" }}>
              Secure checkout. After payment, enter your unlock code.
            </p>

            <div style={{ background: "rgba(2,6,23,.5)", borderRadius: 14, padding: "14px 16px", marginBottom: 22 }}>
              {selPlan.features.map((f) => (
                <div key={f} style={{ color: "#cbd5e1", fontSize: 14, marginBottom: 8, display: "flex", gap: 8 }}>
                  <span style={{ color: "#a3e635" }}>✓</span>
                  {f}
                </div>
              ))}
            </div>

            <a href={PAYPAL[selectedTier] || "#"} target="_blank" rel="noreferrer noopener" style={{ ...S.btn, display: "block", textAlign: "center", fontSize: 16, padding: "16px", marginBottom: 8 }}>
              Secure Checkout - {selPlan.price}
            </a>
            <p style={{ color: "#64748b", fontSize: 12, textAlign: "center", margin: "0 0 22px", lineHeight: 1.5 }}>
              Card, Apple Pay and other options may appear inside PayPal checkout depending on country and account.
            </p>

            <Field label="Which plan did you purchase?">
              <select style={S.inp} value={selectedTier} onChange={(e) => setSelTier(e.target.value)}>
                {PLANS.filter((p) => p.id !== "free").map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} - {p.price}
                  </option>
                ))}
              </select>
            </Field>

            <div style={{ height: 14 }} />

            <Field label="Enter your unlock code">
              <input style={S.inp} value={unlockCode} placeholder="Your unlock code" onChange={(e) => { setUCode(e.target.value); setUError(""); }} />
            </Field>
            {unlockError && <p style={{ color: "#fca5a5", fontSize: 13, margin: "10px 0 0", lineHeight: 1.5 }}>{unlockError}</p>}
            <button onClick={unlockWithCode} style={{ ...S.btn, width: "100%", marginTop: 16 }}>Unlock my plan</button>
            <p style={{ color: "#64748b", fontSize: 11, textAlign: "center", margin: "12px 0 0" }}>Did not receive a code? Email {SUPPORT_EMAIL}</p>
          </div>
        </div>
        <LegalModal type={legalModal} onClose={() => setLegalModal(null)} />
      </div>
    );
  }

  if (screen === "onboarding") {
    return (
      <div style={S.page}>
        <div style={{ ...S.wrap, maxWidth: 640, padding: "28px 0 80px" }}>
          <button onClick={() => setScreen("home")} style={S.sec}>Back</button>
          <LaunchBanner />
          <h1 style={{ fontSize: 40, letterSpacing: -2, margin: "22px 0 6px", lineHeight: 1.05 }}>Tell us about your life.</h1>
          <p style={{ color: "#94a3b8", lineHeight: 1.65, margin: "0 0 24px" }}>No judgment. We use this to build a plan that actually fits you.</p>

          <div style={{ ...S.card, padding: 24, display: "grid", gap: 20 }}>
            {!isPaid(accessTier) && (
              <Field label="Daily calorie target" error={errors.calories}>
                <input style={S.inp} inputMode="numeric" value={form.calories} placeholder="2000" onChange={(e) => setVal("calories", e.target.value)} />
                <div style={{ color: "#64748b", fontSize: 12 }}>Not sure? 2000 cal is a reasonable starting point.</div>
              </Field>
            )}

            {isPaid(accessTier) && (
              <>
                <Field label="My main goal">
                  <select style={S.inp} value={form.goal} onChange={(e) => setVal("goal", e.target.value)}>
                    <option value="lose">Lose weight and feel lighter</option>
                    <option value="maintain">Eat better and maintain my weight</option>
                    <option value="gain">Build muscle and get stronger</option>
                  </select>
                </Field>

                {form.goal === "lose" && (
                  <Field label="How fast do you want to lose?">
                    <select style={S.inp} value={form.lossSpeed} onChange={(e) => setVal("lossSpeed", e.target.value)}>
                      <option value="gentle">Slow and steady - about 200 cal deficit</option>
                      <option value="steady">Moderate - about 400 cal deficit</option>
                      <option value="faster">Faster - about 550 cal deficit</option>
                    </select>
                  </Field>
                )}

                <Field label="Gender">
                  <select style={S.inp} value={form.gender} onChange={(e) => setVal("gender", e.target.value)}>
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                  </select>
                </Field>

                <SliderField label="Age" error={errors.age} value={form.age} onChange={(v) => setVal("age", v)} min={16} max={99} unit="yrs" />
                <SliderField label="Weight" error={errors.weight} value={form.weight} onChange={(v) => setVal("weight", v)} min={30} max={250} unit="kg" />
                <SliderField label="Height" error={errors.height} value={form.height} onChange={(v) => setVal("height", v)} min={120} max={220} unit="cm" />

                <Field label="How active are you day-to-day?">
                  <select style={S.inp} value={form.activity} onChange={(e) => setVal("activity", e.target.value)}>
                    <option value="sedentary">Not very active - mostly sitting</option>
                    <option value="light">A little active - walks, gym 1-2x week</option>
                    <option value="moderate">Moderately active - gym 3-5x week</option>
                    <option value="active">Very active - training most days</option>
                  </select>
                </Field>

                {hasBFP(accessTier) && (
                  <div style={{ borderTop: "1px solid rgba(148,163,184,.1)", paddingTop: 16, display: "grid", gap: 14 }}>
                    <div style={{ color: "#64748b", fontSize: 12, fontWeight: 800, textTransform: "uppercase", letterSpacing: ".07em" }}>Optional - Body Fat Estimate</div>
                    <Field label="Waist (cm) - optional"><input style={S.inp} inputMode="numeric" value={form.waist} placeholder="e.g. 85" onChange={(e) => setVal("waist", e.target.value)} /></Field>
                    <Field label="Neck (cm) - optional"><input style={S.inp} inputMode="numeric" value={form.neck} placeholder="e.g. 38" onChange={(e) => setVal("neck", e.target.value)} /></Field>
                    {form.gender === "female" && <Field label="Hip (cm)"><input style={S.inp} inputMode="numeric" value={form.hip} placeholder="e.g. 95" onChange={(e) => setVal("hip", e.target.value)} /></Field>}
                  </div>
                )}
              </>
            )}

            <Field label="Meals per day">
              <select style={S.inp} value={form.mealsPerDay} onChange={(e) => setVal("mealsPerDay", e.target.value)}>
                <option value="3">3 meals - breakfast, lunch, dinner</option>
                <option value="4">3 meals plus a snack</option>
              </select>
            </Field>

            <Field label="What is your biggest challenge right now?">
              <select style={S.inp} value={form.biggestStruggle} onChange={(e) => setVal("biggestStruggle", e.target.value)}>
                <option value="late_night">Late-night cravings</option>
                <option value="takeout">Too much takeout</option>
                <option value="dont_know">I do not know what to eat</option>
                <option value="training_no_results">I am training but not seeing results</option>
                <option value="busy">Busy schedule - no time to cook</option>
                <option value="boring_diets">I hate boring diets</option>
              </select>
            </Field>

            <Field label="What kind of food do you actually enjoy?">
              <select style={S.inp} value={form.foodPreference} onChange={(e) => setVal("foodPreference", e.target.value)}>
                <option value="balanced">Balanced real food - normal meals</option>
                <option value="highProtein">High protein - meat and protein</option>
                <option value="comfort">Comfort food made smarter</option>
                <option value="budget">Budget-friendly meals</option>
                <option value="mealPrep">Meal prep - cook once, eat multiple times</option>
              </select>
            </Field>

            {hasWorkouts(accessTier) && (
              <div style={{ borderTop: "1px solid rgba(148,163,184,.1)", paddingTop: 16, display: "grid", gap: 14 }}>
                <div style={{ color: "#64748b", fontSize: 12, fontWeight: 800, textTransform: "uppercase", letterSpacing: ".07em" }}>Your Training Setup</div>
                <Field label="How many days per week can you train?">
                  <select style={S.inp} value={form.workoutsPerWeek} onChange={(e) => setVal("workoutsPerWeek", e.target.value)}>
                    <option value="2">2 days</option>
                    <option value="3">3 days</option>
                    <option value="4">4 days</option>
                    <option value="5">5 days</option>
                  </select>
                </Field>
                <Field label="Training style">
                  <select style={S.inp} value={form.workoutStyle} onChange={(e) => setVal("workoutStyle", e.target.value)}>
                    <option value="fullBody">Full Body</option>
                    <option value="upperLower">Upper / Lower split</option>
                    <option value="ppl">Push / Pull / Legs</option>
                  </select>
                </Field>
                <Field label="Where do you train?">
                  <select style={S.inp} value={form.trainingPlace} onChange={(e) => setVal("trainingPlace", e.target.value)}>
                    <option value="gym">Gym</option>
                    <option value="home">Home</option>
                  </select>
                </Field>
                <Field label="Your experience level?">
                  <select style={S.inp} value={form.level} onChange={(e) => setVal("level", e.target.value)}>
                    <option value="beginner">Beginner</option>
                    <option value="intermediate">Intermediate</option>
                    <option value="advanced">Advanced</option>
                  </select>
                </Field>
              </div>
            )}

            <div style={{ borderTop: "1px solid rgba(148,163,184,.1)", paddingTop: 16, display: "grid", gap: 12 }}>
              <Field label="Email for plan updates - optional" error={errors.marketingEmail}>
                <input style={S.inp} type="email" value={form.marketingEmail} placeholder="you@example.com" onChange={(e) => setVal("marketingEmail", e.target.value)} />
              </Field>
              <label style={{ color: "#94a3b8", fontSize: 13, display: "flex", gap: 10, alignItems: "flex-start", lineHeight: 1.5 }}>
                <input type="checkbox" checked={form.marketingConsent} onChange={(e) => setVal("marketingConsent", e.target.checked)} style={{ marginTop: 2, accentColor: "#a3e635" }} />
                I agree to receive NutriPlan updates, offers and wellness content. I can unsubscribe at any time.
              </label>
            </div>

            <div style={{ display: "flex", gap: 12, alignItems: "flex-start", padding: 16, background: "rgba(2,6,23,.5)", borderRadius: 12, border: termsError ? "1px solid #f87171" : "1px solid rgba(148,163,184,.12)" }}>
              <input type="checkbox" id="terms-agree" checked={agreedToTerms} onChange={(e) => { setAgreed(e.target.checked); setTermsError(false); }} style={{ marginTop: 3, accentColor: "#a3e635", width: 18, height: 18, flexShrink: 0, cursor: "pointer" }} />
              <label htmlFor="terms-agree" style={{ color: "#94a3b8", fontSize: 13, lineHeight: 1.6, cursor: "pointer" }}>
                I understand that NutriPlan is not medical advice, results vary, and I am responsible for my own food, allergy and health decisions. I agree to the{" "}
                <span style={{ color: "#a3e635", textDecoration: "underline", cursor: "pointer" }} onClick={() => setLegalModal("terms")}>Terms of Service</span>{" "}
                and{" "}
                <span style={{ color: "#a3e635", textDecoration: "underline", cursor: "pointer" }} onClick={() => setLegalModal("privacy")}>Privacy Policy</span>.
              </label>
            </div>

            {termsError && <p style={{ color: "#f87171", fontSize: 13, margin: 0 }}>Please read and agree to the terms before continuing.</p>}

            <button onClick={generate} style={{ ...S.btn, opacity: generating ? 0.7 : 1, fontSize: 16, padding: "16px" }} disabled={generating}>
              {generating ? "Building your plan..." : "Build My Plan"}
            </button>
          </div>
        </div>
        <LegalModal type={legalModal} onClose={() => setLegalModal(null)} />
      </div>
    );
  }

  if (screen === "results" && plan) {
    const day = plan.days[openDay] || plan.days[0];
    const unlockedRecipes = recipeLimit(plan.tier);

    return (
      <div style={S.page}>
        <div style={{ ...S.wrap, padding: "24px 0 80px" }}>
          <button onClick={() => setScreen("home")} style={S.sec}>Home</button>
          <LaunchBanner />

          <div style={{ marginTop: 24, marginBottom: 18 }}>
            <Pill color="#a3e635">{plan.tier.charAt(0).toUpperCase() + plan.tier.slice(1)} plan</Pill>
            <h1 style={{ fontSize: "clamp(30px,6vw,48px)", letterSpacing: -2, margin: "14px 0 6px", lineHeight: 1.05 }}>Your plan for real life.</h1>
            <p style={{ color: "#94a3b8", margin: 0 }}>Consistency over perfection. Normal food, smarter portions.</p>
          </div>

          {planReady && (
            <div style={{ borderRadius: 14, padding: "14px 18px", background: "rgba(163,230,53,.08)", border: "1px solid rgba(163,230,53,.25)", marginBottom: 20, fontSize: 14, color: "#bbf7d0", display: "flex", alignItems: "center", gap: 10 }}>
              <span>✓</span> Your plan is ready. {leadSaved ? "Your email was saved." : ""}
            </div>
          )}

          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(80px,1fr))", gap: 10, marginBottom: 12 }}>
            <MacroBox icon="🔥" val={plan.cal} label="cal/day" />
            <MacroBox icon="🥩" val={plan.protein + "g"} label="protein" />
            <MacroBox icon="🍚" val={plan.carbs + "g"} label="carbs" />
            <MacroBox icon="🥑" val={plan.fat + "g"} label="fat" />
            {plan.bfp && <MacroBox icon="📏" val={plan.bfp + "%"} label="body fat" />}
          </div>

          <p style={{ color: "#64748b", fontSize: 11, lineHeight: 1.55, margin: "0 0 20px", padding: "10px 14px", background: "rgba(15,23,42,.5)", borderRadius: 10, border: "1px solid rgba(148,163,184,.08)" }}>
            Calories and macros are estimates for educational purposes only. Consult a qualified professional before making major diet or fitness changes.
          </p>

          {plan.tier === "free" && (
            <div style={{ ...S.card, padding: 22, marginBottom: 24, background: "linear-gradient(135deg,rgba(163,230,53,.08),rgba(15,23,42,.8))", border: "1px solid rgba(163,230,53,.3)" }}>
              <Pill>Free preview</Pill>
              <h3 style={{ margin: "12px 0 8px", fontSize: 20 }}>You are seeing 1 day and 1 recipe. The full plan has more.</h3>
              <p style={{ color: "#94a3b8", margin: "0 0 16px", lineHeight: 1.65, fontSize: 14 }}>
                Upgrade to get all 7 days, meal swaps, all recipes and the calculator.
              </p>
              <button onClick={() => choosePlan("pro")} style={S.btn}>Get the full plan - $27</button>
            </div>
          )}

          <div style={{ display: "flex", gap: 8, marginBottom: 20, flexWrap: "wrap" }}>
            {["meals", "recipes", ...(plan.workouts?.length ? ["workout"] : [])].map((t) => (
              <button
                key={t}
                onClick={() => setActiveTab(t)}
                style={{
                  flex: "1 1 160px",
                  background: activeTab === t ? "#a3e635" : "rgba(15,23,42,.72)",
                  color: activeTab === t ? "#020617" : "#cbd5e1",
                  border: "1px solid " + (activeTab === t ? "#a3e635" : "rgba(148,163,184,.16)"),
                  borderRadius: 14,
                  padding: "13px",
                  fontWeight: 800,
                  cursor: "pointer",
                  fontSize: 15,
                  textTransform: "capitalize",
                }}
              >
                {t === "meals" ? "Meal Plan" : t === "recipes" ? "Recipes" : "Workout Plan"}
              </button>
            ))}
          </div>

          {activeTab === "workout" && plan.workouts && plan.workouts.length > 0 && (
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(280px,1fr))", gap: 16 }}>
              {plan.workouts.map((w, i) => <WorkoutCard key={w.title + i} w={w} />)}
            </div>
          )}

          {activeTab === "recipes" && (
            <>
              <h2 style={{ margin: "0 0 16px", fontSize: 26 }}>Recipes</h2>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(290px,1fr))", gap: 16 }}>
                {RECIPES.map((r, i) => <RecipeCard key={r.title} r={r} locked={i >= unlockedRecipes} onUpgrade={() => choosePlan("pro")} />)}
              </div>
            </>
          )}

          {activeTab === "meals" && (
            <>
              <div style={{ display: "flex", gap: 8, overflowX: "auto", paddingBottom: 10, marginBottom: 20, WebkitOverflowScrolling: "touch" }}>
                {plan.days.map((d, i) => (
                  <button
                    key={d.day}
                    onClick={() => setOpenDay(i)}
                    style={{
                      flexShrink: 0,
                      background: openDay === i ? "#a3e635" : "rgba(15,23,42,.72)",
                      color: openDay === i ? "#020617" : "#cbd5e1",
                      border: "1px solid " + (openDay === i ? "#a3e635" : "rgba(148,163,184,.16)"),
                      borderRadius: 999,
                      padding: "10px 16px",
                      fontWeight: 800,
                      cursor: "pointer",
                      whiteSpace: "nowrap",
                      fontSize: 14,
                    }}
                  >
                    {d.day.slice(0, 3)}
                    {d.locked ? " 🔒" : d.isTraining ? " ⚡" : ""}
                  </button>
                ))}
              </div>

              <h2 style={{ margin: "0 0 16px", fontSize: 26 }}>{day.day}</h2>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(290px,1fr))", gap: 16 }}>
                {plan.slots.map((slot) => (
                  <MealCard
                    key={slot}
                    slot={slot}
                    mealObj={day.meals[slot]}
                    locked={day.locked}
                    allowSwap={canSwap(plan.tier) && !day.locked}
                    onSwap={() => swapMeal(openDay, slot)}
                    onUpgrade={() => choosePlan("pro")}
                  />
                ))}
              </div>
            </>
          )}

          <NutriCoach tier={plan.tier} struggle={form.biggestStruggle} onUpgrade={upgradeFrom} />

          {hasCalc(plan.tier) ? (
            <CalorieCalculator />
          ) : (
            <div style={{ ...S.card, padding: 22, marginTop: 20 }}>
              <Pill>Locked</Pill>
              <h3 style={{ margin: "12px 0 6px" }}>Food Calculator</h3>
              <p style={{ color: "#94a3b8", margin: "0 0 16px", lineHeight: 1.6, fontSize: 14 }}>Look up any food using the label on the package. Unlocks with Pro.</p>
              <button onClick={() => choosePlan("pro")} style={S.btn}>Upgrade to Pro - $27</button>
            </div>
          )}

          <LegalFooter onOpen={setLegalModal} />
        </div>
        <LegalModal type={legalModal} onClose={() => setLegalModal(null)} />
      </div>
    );
  }

  return null;
}
